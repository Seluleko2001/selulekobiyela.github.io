document.addEventListener('DOMContentLoaded', function(){
  const y = new Date().getFullYear();
  const yr = document.getElementById('year');
  if(yr) yr.textContent = y;
});